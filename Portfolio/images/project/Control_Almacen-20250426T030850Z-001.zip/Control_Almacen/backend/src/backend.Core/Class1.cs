﻿namespace backend.Core;

public class Class1
{

}
