﻿namespace backend.Shared;

public class Class1
{

}
