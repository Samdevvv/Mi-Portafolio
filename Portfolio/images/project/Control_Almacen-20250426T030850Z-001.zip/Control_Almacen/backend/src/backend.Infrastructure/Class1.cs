﻿namespace backend.Infrastructure;

public class Class1
{

}
